#(
    id: "606cb1051dbd860a23360870"
    text: {@loziniak Add you repo [here](https://github.com/red/red/wiki/%5BLINKS%5D-Scripts-collection) to have it tracked on progress site.}
    html: none
    sent: 6-Apr-2021/19:05:41.285
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/red/red/wiki/%5BLINKS%5D-Scripts-collection}
    )]
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "x8x"
) #(
    id: "606cc4ad458fc52d5f344b78"
    text: {@loziniak ^/^/- You can include a literal none in maps with construction syntax: `map: #(message: #[none])`^/- Be sure to `copy/deep` on your map templates for series in them. And look at ticket #2167 for gotchas.^/- I would break out the prin/print/probe override/reset into helpers, to keep the main loop clean. Also note that to be like `print` your replacement should return unset.^/- Some of the naming is a little confusing on a quick read. e.g. in the loop there's `result`, `case-result`, then `case` that uses `case-result` checks in it. ^/- Since you make files names at the top already, I'd do that for the results file too, rather than having an `arg/3` reference  way down there.}
    html: none
    sent: 6-Apr-2021/20:29:33.589
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: [#(
        number: "2167"
    )]
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "606cda2a9ecc541fc8df158d"
    text: "Fantastic, thanks for feedback."
    html: none
    sent: 6-Apr-2021/22:01:14.569
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6074bd4c97cf5067465ad245"
    text: {Thanks, @greggirwin for review, I included all suggestions: https://github.com/exercism/red-test-runner/pull/5 . Also, I have a problem with isolating *runner*'s context: https://github.com/exercism/red-test-runner/issues/4, I don't have idea how to do it elegantly. Perhaps someone could help?}
    html: none
    sent: 12-Apr-2021/21:36:12.6
    editedAt: "2021-04-12T21:40:09.763Z"
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "greggirwin"
        userId: "55659ddb15522ed4b3e1006f"
        userIds: []
    )]
    issues: [#(
        number: "5"
        repo: "exercism/red-test-runner"
    ) #(
        number: "4"
        repo: "exercism/red-test-runner"
    )]
    meta: none
    v: 3
    fromUser: none
    author: "loziniak"
) #(
    id: "6074c1f72e5574669b31a3dd"
    text: {When executing arbitrary Red code, there's no easy answer. When `protect` is added that will help, and modules should be restrictable, but we don't have those yet. In this case a catch is that you want it in your environment for the `print...` redefinitions. You've probably already thought of the inelegant solution of loading and binding to a context created for the runner (with words you want to catch). }
    html: none
    sent: 12-Apr-2021/21:56:07.906
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "6074c2cc55d78266a63ed1e4"
    text: {more something like:^/```^/test-runner: context [^/^-args: none^/^-slug: none^/^-input-dir: none^/^-...^/]^/^/test-runner/args: load system/script/args^/test-runner/slug: test-runner/args/1^/test-runner/input-dir: to-red-file test-runner/args/2^/...^/```}
    html: none
    sent: 12-Apr-2021/21:59:40.608
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "607617f8dc24646812bc9f3c"
    text: {> loading and binding to a context created for the runner^/^/To be honest - not. Rebinding contexts is still a little bit of magic for me. I'll try to investigate this and maybe learn something useful in the process.}
    html: none
    sent: 13-Apr-2021/22:15:20.529
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6076193646a93d4a19c4b573"
    text: {It *is* magic. :^^) Partly because you can't see it, but also because we don't think of contexts as a thing that exists in natural language. So moving the same word around in contexts is an unnatural act.}
    html: none
    sent: 13-Apr-2021/22:20:38.174
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "60766ca11f84d71853b6e762"
    text: {How so? Context in natural language is ubiquitous. We don't think of it because it is literally everywhere and we switch contexts all the time naturally. But in Red context switching is more explicit and we don't have ambiguous contexts (except in our heads) as in NL.^/}
    html: none
    sent: 14-Apr-2021/4:16:33.297
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "toomasv"
) #(
    id: "6076b010c60826673ba2920c"
    text: {I think I've nailed it, even without using `bind`. Elegant enough for me, as long as it's correct:^/https://github.com/exercism/red-test-runner/pull/6}
    html: none
    sent: 14-Apr-2021/9:04:16.252
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: [#(
        repo: "exercism/red-test-runner"
        number: "6"
    )]
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6077193fc60826673ba3b775"
    text: {@toomasv what I mean is that you can't take a word out of one context in NL and put it in another, where the same word also exists in a different context. e.g. the old `spoon` example just becomes a madman's mantra. The "rock" example from @9214  is different, and makes your point, so maybe there's a meta element here in contexts as data structures versus contexts as part of language. The structure of a sentence provides context in NL, but arbitrarily reassigning context without that "ordered, semantic container" leaves you in the dark about what a word's context might be.}
    html: none
    sent: 14-Apr-2021/16:33:03.932
    editedAt: "2021-04-14T16:35:37.662Z"
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "toomasv"
        userId: "58e74c67d73408ce4f56bd1f"
        userIds: []
    ) #(
        screenName: "9214"
        userId: "57dad69540f3a6eec06570e4"
        userIds: []
    )]
    issues: none
    meta: none
    v: 2
    fromUser: none
    author: "greggirwin"
) #(
    id: "607719b3c60826673ba3b894"
    text: "Ah, yes, now I understand what you mean."
    html: none
    sent: 14-Apr-2021/16:34:59.979
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "toomasv"
) #(
    id: "60771a7d06e2e024e85287c5"
    text: {Your word choice with "explicit" is interesting too, because we *can* write dialects that support implicit context changes, though they'd necessarily be more advanced than simple word matching. }
    html: none
    sent: 14-Apr-2021/16:38:21.633
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "60771cb12e5574669b37ca2b"
    text: {@loziniak are there explicit ordering rules in test cases, so `last words-of ...` is guaranteed to produce what you want?}
    html: none
    sent: 14-Apr-2021/16:47:45.946
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "60784d58d7953918615d18ba"
    text: {Yes. It's up to exercise description to request/enforce a specific form, like a function in [hello-world exercise](https://github.com/exercism/red/blob/main/exercises/practice/hello-world/hello-world.red), where your task is only to modify existing code. A task can always be like "assign output to a word" or similar.}
    html: none
    sent: 15-Apr-2021/14:27:36.877
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/exercism/red/blob/main/exercises/practice/hello-world/hello-world.red}
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "60784db6a2ac0d38e7ba0b4a"
    text: {`last words-of ...` takes a value of last assignment in student's answer script.}
    html: none
    sent: 15-Apr-2021/14:29:10.722
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "60784e4cb6a4714a29c7842b"
    text: {I realised though, that my solution only stops from overwriting *test-runner* context by *answer*, and still access to this context is possible (like `append output "something"`, so it's just partially a success :-/}
    html: none
    sent: 15-Apr-2021/14:31:40.939
    editedAt: "2021-04-15T14:33:14.114Z"
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 3
    fromUser: none
    author: "loziniak"
) #(
    id: "60788bd9c60826673ba780ad"
    text: {You should be able to use a prototype object that contains the words you want to protect. But if you need access to those from the caller, you'll also have to use a path to the test runner. }
    html: none
    sent: 15-Apr-2021/18:54:17.752
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "607921732e5574669b3cfafe"
    text: {Ah, so [my example from monday ↑↑](https://gitter.im/red/training?at=6074c2cc55d78266a63ed1e4) seems to be the only solution? I'd like to protect all words if possible. Code will be messy unfortunately with all the paths to *test-runner* context. Perhaps that could ne a good *WISH*? :-)}
    html: none
    sent: 16-Apr-2021/5:32:35.639
    unread: none
    readBy: none
    urls: [#(
        url: {https://gitter.im/red/training?at=6074c2cc55d78266a63ed1e4}
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "607948ff55d78266a64a887a"
    text: {At small scale I managed to come up with this:^/```^/>> context [a: "12" context bind [ append a "3"] system/words]^/*** Script Error: a has no value^/*** Where: append^/*** Stack: context context  ^/```^/but when I try to apply it to the test-runner script, I fail.}
    html: none
    sent: 16-Apr-2021/8:21:19.978
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6079558681866c680c28758b"
    text: {Ok, I made it! [there was a word name collision](https://github.com/exercism/red-test-runner/pull/6/commits/38518e1cfe036ce8213bca455ac7dfcc2b9d94cc#diff-d30f0556f01e449182531e3ad1f25c99829e22d8956a3c8bbd4c793fcecb2862R119) between *test-runner.red* and *test-runner-test.red*.}
    html: none
    sent: 16-Apr-2021/9:14:46.098
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/exercism/red-test-runner/pull/6/commits/38518e1cfe036ce8213bca455ac7dfcc2b9d94cc#diff-d30f0556f01e449182531e3ad1f25c99829e22d8956a3c8bbd4c793fcecb2862R119}
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6079e869a2ac0d38e7be43d0"
    text: {Glad you solved it. Be careful on the naming treadmill. %red-test-runner-runner-test.red may be next, and a palindrome to boot! :^^)}
    html: none
    sent: 16-Apr-2021/19:41:29.091
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "608291e2a2ac0d38e7d33934"
    text: {A nice article by Elm track maintainers on changes comming to Exercism:^/https://hackmd.io/60gYIZYYS-6_l8kLH0QXAQ?view^/Most applies also to [Red track](https://github.com/exercism/red/).}
    html: none
    sent: 23-Apr-2021/9:22:42.013
    editedAt: "2021-04-23T09:23:44.522Z"
    unread: none
    readBy: none
    urls: [#(
        url: "https://hackmd.io/60gYIZYYS-6_l8kLH0QXAQ?view"
    ) #(
        url: "https://github.com/exercism/red/"
    )]
    mentions: none
    issues: none
    meta: none
    v: 3
    fromUser: none
    author: "loziniak"
) #(
    id: "6082ce1e81866c680c3fb77a"
    text: "Thanks @loziniak. Will try to read later today."
    html: none
    sent: 23-Apr-2021/13:39:42.432
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "60c34d6cbed13a2dba7a3329"
    text: {Exercism moves to a ["phased" beta](https://exercism.lol/) stage, and here is the Red track for preview:^/https://exercism.lol/tracks/red}
    html: none
    sent: 11-Jun-2021/11:47:56.371
    unread: none
    readBy: none
    urls: [#(
        url: "https://exercism.lol/"
    ) #(
        url: "https://exercism.lol/tracks/red"
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "60c3aab5c705e53c1c881eb0"
    text: {Nice! I will try to check it out in detail soon. If someone, like me perchance, were to help, maybe wordsmitting the intro to start, how best to contribute?}
    html: none
    sent: 11-Jun-2021/18:25:57.994
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "60c3df39d161a54f050e66ad"
    text: {Wordsmitting would be especially great, given my non-native English. Also general testing, proof-reading and review. Also, check ["contributing"](https://github.com/exercism/red/#contributing) section in readme.}
    html: none
    sent: 11-Jun-2021/22:10:01.339
    unread: none
    readBy: none
    urls: [#(
        url: "https://github.com/exercism/red/#contributing"
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "60c3e1345e8dfc4f1177c353"
    text: {Also, as fresh *reducer* I may have not enough practice and insight to create exhaustive [concept](https://github.com/exercism/docs/blob/main/building/tracks/concepts.md) learning flow. Good example is in Elixir track: https://exercism.lol/tracks/elixir/concepts}
    html: none
    sent: 11-Jun-2021/22:18:28.819
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/exercism/docs/blob/main/building/tracks/concepts.md}
    ) #(
        url: "https://exercism.lol/tracks/elixir/concepts"
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "60c3e4f88681550d4ee5e09d"
    text: {Thanks. It's a great start. I just love to tinker with words. :^^) @galenivanov might have some thoughts, as he's working on Python primers now.}
    html: none
    sent: 11-Jun-2021/22:34:32.731
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "galenivanov"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "6135741cd206b85e4f81b215"
    text: {Exercism v3 is alive:^/https://exercism.org/^/And Red is almost there :-)}
    html: none
    sent: 6-Sep-2021/1:51:24.99
    unread: none
    readBy: none
    urls: [#(
        url: "https://exercism.org/"
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "61357ec35b92082de1876079"
    text: "Great! Thanks. "
    html: none
    sent: 6-Sep-2021/2:36:51.192
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "61357ec55b92082de1876080"
    text: "Cool!"
    status: false
    html: none
    sent: 6-Sep-2021/2:36:53.52
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    virtualUser: #(
        type: "matrix"
        externalId: "zentrog:matrix.org"
        displayName: "zentrog"
        avatarUrl: {https://user-content.gitter-static.net/07a3a838bf61f3975c3ec2e7049c5bc6cd01650c/68747470733a2f2f6769747465722e656d732e686f73742f5f6d61747269782f6d656469612f72302f646f776e6c6f61642f6d61747269782e6f72672f72757575764e7152636b45546a6d767873756b5954696574}
    )
    fromUser: none
    author: "zentrog:matrix.org"
) #(
    id: "614df704f428f97a9fa4444b"
    text: {Hello. If anyone wants to solve some exercises in Red, I'm working on preparing first 20 exercises batch for Exercism, and the most work there is to provide example solutions. Here is the list: https://github.com/exercism/red/issues/31#issuecomment-859965936}
    html: none
    sent: 24-Sep-2021/16:04:20.066
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/exercism/red/issues/31#issuecomment-859965936}
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "614df7d1d206b85e4fb77f71"
    text: {Anyone interested, just comment on this issue #31, or create separate issue.}
    html: none
    sent: 24-Sep-2021/16:07:45.753
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: [#(
        number: "31"
    )]
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6158d3bccd4972068b266e6d"
    text: {Hi @loziniak, I would be happy to try a couple of simple ones. I will do the "Hello World" one later today.}
    html: none
    sent: 2-Oct-2021/21:48:44.043
    editedAt: "2021-10-02T21:53:16.751Z"
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 2
    fromUser: none
    author: "wallysilva"
) #(
    id: "6159088ccd4972068b26cda8"
    text: {@loziniak, I believe you can find some of the solutions in the Rosetta Code. For instance, the solution for the Roman Numerals problem: http://www.rosettacode.org/wiki/Roman_numerals/Decode#Red}
    html: none
    sent: 3-Oct-2021/1:34:04.499
    unread: none
    readBy: none
    urls: [#(
        url: {http://www.rosettacode.org/wiki/Roman_numerals/Decode#Red}
    )]
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "wallysilva"
) #(
    id: "615a0b9229ddcd029300ff46"
    text: "Oh, nice. Thanks."
    html: none
    sent: 3-Oct-2021/19:59:14.8
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6170642229ddcd0293336e86"
    text: {@loziniak: I've been casually interested in Excercism for a while, but now that there is someone driving this effort, it feels like the little chunks are small enough that I can actually contribute. I really appreciate your effort on this!^/I was thinking more about the exercise test runner, and the part which feels a little awkward to me is editing the file and knowing to change the `ignore-after` field. That and switching to use the example solution. What would you think about adding some optional arguments to the test script to specify how many tests to run, and a way to target the example solution?^/I should probably look at some other language tracks to see how they are doing it, but that was just based on my impression. I haven't seen yet how this compares with a user of the track vs someone adding examples.}
    status: false
    html: none
    sent: 20-Oct-2021/18:46:58.906
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    virtualUser: #(
        type: "matrix"
        externalId: "zentrog:matrix.org"
        displayName: "zentrog"
        avatarUrl: {https://user-content.gitter-static.net/07a3a838bf61f3975c3ec2e7049c5bc6cd01650c/68747470733a2f2f6769747465722e656d732e686f73742f5f6d61747269782f6d656469612f72302f646f776e6c6f61642f6d61747269782e6f72672f72757575764e7152636b45546a6d767873756b5954696574}
    )
    fromUser: none
    author: "zentrog:matrix.org"
) #(
    id: "6170ad6929ddcd0293342213"
    text: {Hi @zentrog:matrix.org . Thanks for contributions so far, the greatest of them is just being here and participating, so it doesn't feel being on my own anymore :-)^/The test script is certainly not perfect, the main problem being the code repeated in every exercise and I don't have a clear idea how to get over it.^/Editing the `ignore-after` value is a little awkward for me too, but it's just like this in every other track. Usually they use some testing framework, and all (except the 1st) test cases are manually bypassed ([csharp track example](https://github.com/exercism/csharp/blob/main/exercises/practice/darts/DartsTests.cs)). Personally, I'd just enable all tests by default, although I think I've read somewhere, that enabling tests one-by-one is a recommended practice in TDD. Having this as an optional argument is probably ok. Perhaps @iHiD would have a say here?^/Switching to example solution is done only, when creating exercise. Final users "consume" the example just by copying it to main example file, which they then test.}
    html: none
    sent: 20-Oct-2021/23:59:37.989
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/exercism/csharp/blob/main/exercises/practice/darts/DartsTests.cs}
    )]
    mentions: [#(
        screenName: "zentrog:matrix.org"
        userIds: []
    ) #(
        screenName: "iHiD"
        userId: "5e765825d73408ce4fdd8e1f"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6170affc29ddcd0293342698"
    text: {Oh, wow. Removing the Skips is way more cumbersome!^/If it helps, I think what you have so far seems great. And the fact that the test scripts can be auto-generated means they could potentially be updated the same way. I don't think it is a high priority, but I thought I should mention it to see if you think it's something worth pursuing.^/The idea I had was something simple like the first time you run the tests, it would give a hint like^/```^/red --cli darts-test.red^/Running 1 of 13 tests...^/<test results>^/Run "darts-test.red 2" to run the next test^/```^/Then you just need to press <up> and change the number each time}
    status: false
    html: none
    sent: 21-Oct-2021/0:10:36.774
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    virtualUser: #(
        type: "matrix"
        externalId: "zentrog:matrix.org"
        displayName: "zentrog"
        avatarUrl: {https://user-content.gitter-static.net/07a3a838bf61f3975c3ec2e7049c5bc6cd01650c/68747470733a2f2f6769747465722e656d732e686f73742f5f6d61747269782f6d656469612f72302f646f776e6c6f61642f6d61747269782e6f72672f72757575764e7152636b45546a6d767873756b5954696574}
    )
    fromUser: none
    author: "zentrog:matrix.org"
) #(
    id: "6170b3e9a41fd20699f59659"
    text: {I'd probably go rather for the argument being a number of tests to run, than number of a test. Then user can easily fire all the tests at once. And if making test *n* pass would break any earlier tests, it will be evident.^/Thanks for warm feedback. In fact, I thought also about automatic updates. Just didn't need it so far. And keeping custom changes intact (like for example adding few track-specific test cases) would need some thought.}
    html: none
    sent: 21-Oct-2021/0:27:21.616
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6170b5432197144e8478b0f1"
    text: {Btw now that I think about it, having an example solution just seems to be needed for unit-testing exercise's tests by CI/CD scripts, and not being copied by students :-)}
    html: none
    sent: 21-Oct-2021/0:33:07.269
    editedAt: "2021-10-21T00:34:00.313Z"
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 3
    fromUser: none
    author: "loziniak"
) #(
    id: "6170baa8a41fd20699f5a6e3"
    text: {That's actually the way I was thinking about it as well - the number would just set ignore-after if it was present. The reason for that message is more to provide a hint as to what to do next, not explicitly describing the usage of the command}
    status: false
    html: none
    sent: 21-Oct-2021/0:56:08.126
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    virtualUser: #(
        type: "matrix"
        externalId: "zentrog:matrix.org"
        displayName: "zentrog"
        avatarUrl: {https://user-content.gitter-static.net/07a3a838bf61f3975c3ec2e7049c5bc6cd01650c/68747470733a2f2f6769747465722e656d732e686f73742f5f6d61747269782f6d656469612f72302f646f776e6c6f61642f6d61747269782e6f72672f72757575764e7152636b45546a6d767873756b5954696574}
    )
    fromUser: none
    author: "zentrog:matrix.org"
) #(
    id: "6170baf12197144e8478bdb0"
    text: {That's quite interesting about the unit tests. It seems like it would need a way to run all the tests as well}
    status: false
    html: none
    sent: 21-Oct-2021/0:57:21.241
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    virtualUser: #(
        type: "matrix"
        externalId: "zentrog:matrix.org"
        displayName: "zentrog"
        avatarUrl: {https://user-content.gitter-static.net/07a3a838bf61f3975c3ec2e7049c5bc6cd01650c/68747470733a2f2f6769747465722e656d732e686f73742f5f6d61747269782f6d656469612f72302f646f776e6c6f61642f6d61747269782e6f72672f72757575764e7152636b45546a6d767873756b5954696574}
    )
    fromUser: none
    author: "zentrog:matrix.org"
) #(
    id: "617156f27db1e3753e52f32e"
    text: {There is some info on CI on Exercism, still a TODO on a Red track:^/https://exercism.org/docs/building/tracks/ci}
    html: none
    sent: 21-Oct-2021/12:02:58.501
    unread: none
    readBy: none
    urls: [#(
        url: "https://exercism.org/docs/building/tracks/ci"
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6171b01bf2cedf67f99a8010"
    text: {Thanks for jumping in @zentrog:matrix.org. I keep hoping to make time to dig into this, but my best laid plans...aren't. }
    html: none
    sent: 21-Oct-2021/18:23:23.445
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "zentrog:matrix.org"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "6171b4d1cd4972068b5e83b6"
    text: {@loziniak: Thanks for the link!^/I found an interesting issue with the sgf-parser exercise, which is that the canonical data uses the property "parse", which makes the generated code use that name for the exercise stub function. That causes an obvious conflict with `parse`. The simple fix would be to just rename those to something that doesn't conflict. But it raises the question of whether there needs to be a mechanism to remap certain names, because it breaks the automation for that exercise.}
    status: false
    html: none
    sent: 21-Oct-2021/18:43:29.627
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    virtualUser: #(
        type: "matrix"
        externalId: "zentrog:matrix.org"
        displayName: "zentrog"
        avatarUrl: {https://user-content.gitter-static.net/07a3a838bf61f3975c3ec2e7049c5bc6cd01650c/68747470733a2f2f6769747465722e656d732e686f73742f5f6d61747269782f6d656469612f72302f646f776e6c6f61642f6d61747269782e6f72672f72757575764e7152636b45546a6d767873756b5954696574}
    )
    fromUser: none
    author: "zentrog:matrix.org"
) #(
    id: "6171b590a41fd20699f80252"
    text: {@greggirwin: I'm shocked that your plans are a bit overloaded 😏 (<- if it's hard to see what that is, it's the smirking/sly smile face, btw)}
    status: false
    html: none
    sent: 21-Oct-2021/18:46:40.978
    editedAt: "2021-10-21T18:48:01.818Z"
    threadMessageCount: 2
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "greggirwin"
        userId: "55659ddb15522ed4b3e1006f"
        userIds: []
    )]
    issues: none
    meta: none
    v: 4
    virtualUser: #(
        type: "matrix"
        externalId: "zentrog:matrix.org"
        displayName: "zentrog"
        avatarUrl: {https://user-content.gitter-static.net/07a3a838bf61f3975c3ec2e7049c5bc6cd01650c/68747470733a2f2f6769747465722e656d732e686f73742f5f6d61747269782f6d656469612f72302f646f776e6c6f61642f6d61747269782e6f72672f72757575764e7152636b45546a6d767873756b5954696574}
    )
    fromUser: none
    author: "zentrog:matrix.org"
) #(
    id: "6171b683fb8ca0572bd5baa2"
    text: "I got it. ;^^)"
    html: none
    sent: 21-Oct-2021/18:50:43.265
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "6172c95998c13e7550ed60b7"
    text: {@zentrog:matrix.org I think it's just fine to rename it, as currently we don't have exercise re-generation code. I think when we do, then we'll start to worry. I think there will be little cases like that, and we can deal with them by manually merging changes with git to preserve edits. If it will be too much work, then perhaps would be a good moment to start thinking about renaming in case of system/words conflict.}
    html: none
    sent: 22-Oct-2021/14:23:21.823
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "zentrog:matrix.org"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
)#(
    id: "606c772c657d022d5a668237"
    text: {Busy day here, but will try to review before long. I added @x8x here, as I agree that tracking Red on Exercism would be great for progress.red-lang.org.}
    html: none
    sent: 6-Apr-2021/14:58:52.314
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "x8x"
        userId: "55740d7815522ed4b3e18b35"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "606c63c1d765936399d92c4c"
    text: {Also – what's the requirement for a repo to be included in *progress.red-lang.org*? It'd be nice to see Exercism track changes there.}
    html: none
    sent: 6-Apr-2021/13:36:01.354
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "606c62a33153ce63a3c160aa"
    text: {I've written a [test runner for Exercism](https://github.com/exercism/red-test-runner). I'd appreciate a code review from Red point of view.}
    html: none
    sent: 6-Apr-2021/13:31:15.604
    unread: none
    readBy: none
    urls: [#(
        url: "https://github.com/exercism/red-test-runner"
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6048551222a5ce4a9145e7aa"
    text: {Thanks @loziniak. Will try to catch up and review soon.}
    html: none
    sent: 10-Mar-2021/5:11:46.205
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "60484de5e562cf54acae56d6"
    text: "Great job!👏🏻👏🏻👏🏻"
    html: none
    sent: 10-Mar-2021/4:41:09.572
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "wallysilva"
) #(
    id: "6046331195e23446e41e4c7b"
    text: {Ah, and a code snippet: https://github.com/loziniak/red-1/blob/docs/docs/SNIPPET.txt}
    html: none
    sent: 8-Mar-2021/14:22:09.372
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/loziniak/red-1/blob/docs/docs/SNIPPET.txt}
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "604630d9d1aee44e2dd125e0"
    text: {Also couple words about installation: https://github.com/loziniak/red-1/blob/docs/docs/INSTALLATION.md}
    html: none
    sent: 8-Mar-2021/14:12:41.339
    threadMessageCount: 3
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/loziniak/red-1/blob/docs/docs/INSTALLATION.md}
    )]
    mentions: none
    issues: none
    meta: none
    v: 4
    fromUser: none
    author: "loziniak"
) #(
    id: "604623f0d2619a4f2e2ecc32"
    text: {Hello. I created a summary page for Red: https://github.com/loziniak/red-1/blob/docs/docs/ABOUT.md^/Let me know if there's something you would change.}
    html: none
    sent: 8-Mar-2021/13:17:36.39
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/loziniak/red-1/blob/docs/docs/ABOUT.md}
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "60298fa84c79215749e7e7cc"
    text: {Exercism is now in a transition between v2 and v3. Current site is in maintenance mode, so I don't know if new tracks can be tested there. But there is also a test version of v3, and I hope it can be used to test fresh exercises. Athough, it's at dev/pre-alpha stage.}
    html: none
    sent: 14-Feb-2021/21:01:28.473
    editedAt: "2021-02-14T21:02:49.568Z"
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 3
    fromUser: none
    author: "loziniak"
) #(
    id: "602963baa7fc4b573bd45c7a"
    text: {Thanks @wallysilva. We will indeed need people to do that.}
    html: none
    sent: 14-Feb-2021/17:54:02.436
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "wallysilva"
        userId: "56b91c8ee610378809c07eed"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "6028d1c9726a881d4f733f19"
    text: {Oooh, this is cool stuff! If you guys need some one to try the exercises, I will be happy to be your a guinea pig :D}
    html: none
    sent: 14-Feb-2021/7:31:21.96
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "wallysilva"
) #(
    id: "602855b3e634904e609b08f5"
    text: {Woohoo! Thanks @loziniak. I will try to review in the next few days.}
    html: none
    sent: 13-Feb-2021/22:41:55.541
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "60284bbf8621811d5875e065"
    text: {Added first exercise: https://github.com/exercism/red/pull/7}
    html: none
    sent: 13-Feb-2021/21:59:27.374
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: [#(
        repo: "exercism/red"
        number: "7"
    )]
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6026f150a0246860dc4b6014"
    text: ":+1:"
    html: none
    sent: 12-Feb-2021/21:21:20.939
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "6026f070063b6c68d5571dba"
    text: {>  if there are transcripts of mentoring sessions, that would be great too^/^/They don't give that. Instead, I've been pointed at mentoring instructions, that are available to every exercise:^/https://github.com/exercism/website-copy/blob/main/tracks/ruby/exercises/resistor-color-duo/mentoring.md}
    html: none
    sent: 12-Feb-2021/21:17:36.276
    unread: none
    readBy: none
    urls: [#(
        url: {https://github.com/exercism/website-copy/blob/main/tracks/ruby/exercises/resistor-color-duo/mentoring.md}
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6026eaf755359c58bf3bee94"
    text: "Done."
    html: none
    sent: 12-Feb-2021/20:54:15.144
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "6026eadb4f7d1b68e54aa85e"
    text: {> Agreed on testing^/^/Thanks! Would you mind commenting also on GitHub?}
    html: none
    sent: 12-Feb-2021/20:53:47.052
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6026e7ff32e01b4f71908bb3"
    text: {Yes. In the very near future (we hope) the Red DL will be the prebuilt console directly, so you can run instantly, but it's not that way yet. ^/^/Agreed on testing. I roll special case testers, and we'll find what works well there. I don't think `quick-test` is the best choice for this purpose.}
    html: none
    sent: 12-Feb-2021/20:41:35.461
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "6026e6295500a97f8202fb61"
    text: {@greggirwin ^/> should we point people to a prebuilt console^/^/What do you mean? Are you talking about how installation instructions should look like?^/^/> do we want a simple test runner^/^/https://github.com/exercism/red/issues/5}
    html: none
    sent: 12-Feb-2021/20:33:45.023
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "greggirwin"
        userId: "55659ddb15522ed4b3e1006f"
        userIds: []
    )]
    issues: [#(
        repo: "exercism/red"
        number: "5"
    )]
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6025a6c484e66b7f7ee8dad8"
    text: {Ok, seems not so green, because write access does not equal access to settings (and thus webhooks). So, I think let's leave it for now.}
    html: none
    sent: 11-Feb-2021/21:51:00.555
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6025a420063b6c68d553eb7b"
    text: {Anyway, there's also happily a green light from Gitter: https://gitter.im/gitter/gitter?at=60259f665500a97f82ffca27 . Indeed, a blazing fast response from them.}
    html: none
    sent: 11-Feb-2021/21:39:44.131
    unread: none
    readBy: none
    urls: [#(
        url: {https://gitter.im/gitter/gitter?at=60259f665500a97f82ffca27}
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6025a36a32e01b4f718d6727"
    text: {I wasn't sure on granting webhook access, but it looks like that has to be done on the repo. I'm happy to be a maintainer there, or we can ask someone from Exercism to grant the access if they prefer.}
    html: none
    sent: 11-Feb-2021/21:36:42.301
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "6025a0bb55359c58bf38c259"
    text: {I asked on *gitter/gitter*. @greggirwin, perhaps you could become a Exercism maintainer with write access to github.com/exercism/red, is that what you mean by "granting access" and want to stay away from?}
    html: none
    sent: 11-Feb-2021/21:25:15.055
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "greggirwin"
        userId: "55659ddb15522ed4b3e1006f"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "60254f66aa6a6f319d1c8aa1"
    text: {Integrations and granting access I don't want to rush through, if that's the answer. Let me know what you find out @loziniak.}
    html: none
    sent: 11-Feb-2021/15:38:14.432
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "60254eeb84e66b7f7ee7f10d"
    text: {There's an option when you create the room, which I didn't use. Will check quickly here.}
    html: none
    sent: 11-Feb-2021/15:36:11.001
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
) #(
    id: "60252efd9238c531ad3b4360"
    text: "Thanks @rebolek , I'll check this."
    html: none
    sent: 11-Feb-2021/13:19:57.249
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "rebolek"
        userId: "5565a4bf15522ed4b3e100bc"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "60251be7a0246860dc46c1b6"
    text: {@loziniak I'm not sure, you can try asking at https://gitter.im/gitter/gitter . They're usually very fast to respond.}
    html: none
    sent: 11-Feb-2021/11:58:31.684
    unread: none
    readBy: none
    urls: [#(
        url: "https://gitter.im/gitter/gitter"
    )]
    mentions: [#(
        screenName: "loziniak"
        userId: "5a7ad629d73408ce4f8c1077"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "rebolek"
) #(
    id: "6025128e9238c531ad3af7a9"
    text: {Hi! Is it possible to connect this channel's "github-feed" to `exercism/red` repository?}
    html: none
    sent: 11-Feb-2021/11:18:38.63
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
) #(
    id: "6024929755359c58bf360199"
    text: {Hi! Just made some changes to Excercism track:^/https://github.com/exercism/red/commit/ba808a83cfff5d864d6cacae660a4e4d47ead33b^/https://github.com/exercism/red/pull/2}
    html: none
    sent: 11-Feb-2021/2:12:39.905
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: [#(
        repo: "exercism/red"
        number: "2"
    )]
    meta: none
    v: 1
    fromUser: none
    author: "loziniak"
)