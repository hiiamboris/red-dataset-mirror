#(
    id: "5acec3486d7e07082be5508a"
    text: "👌"
    html: none
    sent: 12-Apr-2018/2:24:08.626
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "peterkwok2018"
)