#(
    id: "62b365e276cd751a2f507697"
    text: {**Welcome to Rethink!**^/^/This is a new channel intended to help us have a little fun, demonstrate clever Red tricks, and generally show what we can do. *Thanks to Gregg for setting it up.*^/^/We’ll publish the occasional Red puzzle, quiz, code optimization challenge; things like that. Any one can join in and publish their solution. And, between us, we’ll all learn something, and perhaps produce some exemplary code.^/^/I am going to start with a puzzle about a strange block ....^/}
    html: none
    sent: 22-Jun-2022/18:56:34.715
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "dsunanda"
) #(
    id: "62b3660c568c2c30d3de466a"
    text: {**Self-aware block**: *How was the `puzzle` block created?*^/^/```^/probe puzzle^/== [3 + 2 2 * 3 3 - 2 2 - 3]^/^/reduce puzzle^/== [First Five then Six and then One and finally Minus One. Ta-da!]^/^/reduce load mold puzzle^/== [5 6 1 -1]^/```^/^/*There's many ways to create the block. For an added challenge, can you do it in pure Red (no Red/System); without redefining `load`, `mold`, `probe`, or `reduce`; and no Unicode trickery?*}
    html: none
    sent: 22-Jun-2022/18:57:16.712
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "dsunanda"
) #(
    id: "62b3690776cd751a2f507c49"
    text: {Clever! :)^/I suppose block is bound to a context with custom operators which evaluate their result, count the position in the block and then spit out words. But then why there are so many items in the reduced block? Wow! Maybe operators have been given a reference to the block then, so they can insert stuff?}
    html: none
    sent: 22-Jun-2022/19:09:59.146
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "hiiamboris"
) #(
    id: "62b37861fe909e3ec7e2e45b"
    text: {I also think ops find places where they are located in that block, and insert lit-words after that position, so when reduce picks up it sees more than there was initially in that block. }
    html: none
    sent: 22-Jun-2022/20:15:29.404
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "hiiamboris"
) #(
    id: "62b390fad3c8894f719a30d3"
    text: {I think the "self-aware" hint lines up with the context idea.}
    html: none
    sent: 22-Jun-2022/22:00:26.42
    editedAt: "2022-06-22T22:00:38.635Z"
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 2
    fromUser: none
    author: "greggirwin"
) #(
    id: "62b4dd031227f62be3b47aba"
    text: {Not many takers for that first challenge .... That challenges us to come up with some better ones. Thanks to Boris for giving it a great deal of thought. And to anyone else who joined in silently.^/^/Here's a hint that more than half solves the puzzle -- so look away now if you don't want to know.^/^/All the entries in the `puzzle` block are simply Red words. "+" and "-" turn into word with `to-word`. To make digits into words we ask `load` nicely.^/^/Here's a version of doing that - which appears to create a block that doubles in value when `reduce`d:^/^/```^/lsw: does [last words-of system/words]^/hint: copy []^/foreach [w n] [1 2 -3 -6 5x25 10x50 3.14159 tau][load rejoin ["/" w] set lsw n append hint lsw] ^/probe hint^/== [1 -3 5x25 3.14159]  ;; four words^/reduce hint^/== [2 -6 10x50 tau]     ;; and the values they hold^/```}
    html: none
    sent: 23-Jun-2022/21:37:07.111
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "dsunanda"
) #(
    id: "62b4e32a3bbb38488991fc1d"
    text: {omg I never would have thought lol ^/```^/>> /2^/== /2^/>> last words-of system/words^/== 2^/>> type? last words-of system/words^/== word!^/```}
    html: none
    sent: 23-Jun-2022/22:03:22.213
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "hiiamboris"
) #(
    id: "62b4e3401227f62be3b4a828"
    text: "language abuse 90 lvl :D"
    html: none
    sent: 23-Jun-2022/22:03:44.328
    unread: none
    readBy: none
    urls: none
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "hiiamboris"
) #(
    id: "62b4e75eef5ee44882c33a37"
    text: {:) Carl used to say that Rebol was a deep lake.^/http://www.rebol.com/article/0103.html^/There's a lot of useful junk at the bottom.}
    html: none
    sent: 23-Jun-2022/22:21:18.657
    unread: none
    readBy: none
    urls: [#(
        url: "http://www.rebol.com/article/0103.html"
    )]
    mentions: none
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "dsunanda"
) #(
    id: "62b4f4160a5226479862bd8d"
    text: {@dsunanda you started with a *really* hard puzzle. I have to block out time for things that deep. :^^)}
    html: none
    sent: 23-Jun-2022/23:15:34.526
    unread: none
    readBy: none
    urls: none
    mentions: [#(
        screenName: "dsunanda"
        userId: "5667eafe16b6c7089cbe0486"
        userIds: []
    )]
    issues: none
    meta: none
    v: 1
    fromUser: none
    author: "greggirwin"
)